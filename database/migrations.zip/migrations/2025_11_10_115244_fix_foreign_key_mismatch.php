<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class FixForeignKeyMismatch extends Migration
{
    public function up()
    {
        // Désactiver temporairement les contraintes de clé étrangère
        DB::statement('SET FOREIGN_KEY_CHECKS=0');

        try {
            // Supprimer la contrainte existante si elle existe
            if (Schema::hasColumn('book_loans', 'user_id')) {
                Schema::table('book_loans', function ($table) {
                    $sm = Schema::getConnection()->getDoctrineSchemaManager();
                    $foreignKeys = $sm->listTableForeignKeys('book_loans');
                    
                    foreach ($foreignKeys as $foreignKey) {
                        if (in_array('user_id', $foreignKey->getLocalColumns())) {
                            $table->dropForeign([$foreignKey->getName()]);
                        }
                    }
                });
            }

            // Forcer la modification du type de la colonne
            DB::statement('ALTER TABLE `book_loans` 
                          MODIFY COLUMN `user_id` INT UNSIGNED NOT NULL');

            // Recréer la contrainte de clé étrangère
            Schema::table('book_loans', function ($table) {
                $table->foreign('user_id')
                      ->references('id')
                      ->on('users')
                      ->onDelete('cascade')
                      ->onUpdate('cascade');
            });
        } catch (\Exception $e) {
            // Afficher l'erreur pour le débogage
            echo "Erreur lors de la migration: " . $e->getMessage() . "\n";
            throw $e;
        } finally {
            // Toujours réactiver les contraintes
            DB::statement('SET FOREIGN_KEY_CHECKS=1');
        }
    }

    public function down()
    {
        // Cette migration est irréversible car elle corrige un problème de schéma
    }
}